# Project permanently moved to https://pypi.org/project/zetamac-tui and https://github.com/yaofanfish/zetamac-tui
